package com.ibm.toneanalyzer.util;

public class ErrorHandling {

}
