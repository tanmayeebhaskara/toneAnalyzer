package com.ibm.toneanalyzer.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ibm.cloud.sdk.core.security.IamAuthenticator;
import com.ibm.cloud.sdk.core.service.exception.NotFoundException;
import com.ibm.cloud.sdk.core.service.exception.RequestTooLargeException;
import com.ibm.cloud.sdk.core.service.exception.ServiceResponseException;
import com.ibm.watson.tone_analyzer.v3.ToneAnalyzer;
import com.ibm.watson.tone_analyzer.v3.model.ToneAnalysis;
import com.ibm.watson.tone_analyzer.v3.model.ToneOptions;

@Service
public class ToneAnalyzerService {

	// private String serviceUrl;
	@Value("${tone.url}")
	private String url;

	@Value("${tone.apikey}")
	private String apikey;

	public String toneAnalyzer(String text) {
		IamAuthenticator authenticator = new IamAuthenticator(apikey);
		ToneAnalyzer toneAnalyzer = new ToneAnalyzer("2017-09-21", authenticator);

		ToneAnalysis toneAnalysis;
		try {
			toneAnalyzer.setServiceUrl(url);
			ToneOptions toneOptions = new ToneOptions.Builder().text(text).build();

			toneAnalysis = toneAnalyzer.tone(toneOptions).execute().getResult();
			System.out.println(toneAnalysis);
			return toneAnalysis.toString();
		} catch (NotFoundException e) {
			return "A requested item or parameter does not exist, please contact the developer";
		} catch (RequestTooLargeException e) {
			return "Request is too large, please try again with a request of shorter length";
		} catch (ServiceResponseException e) {
			return "Service returned response code " + e.getStatusCode() + " " + e.getMessage();
		}
	}
}
