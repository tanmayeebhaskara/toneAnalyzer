package com.ibm.toneanalyzer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.toneanalyzer.service.ToneAnalyzerService;

@RestController
@RequestMapping("/toneanalyzer")
public class ToneAnalyzerController {
	
	@Autowired
	private ToneAnalyzerService analyzerService;
	
	/*
	 * @RequestMapping("hello") public String hello() { System.out.println("hello");
	 * return "hello"; }
	 */
	
	@RequestMapping(method = RequestMethod.GET, value="/analyzetext")
	public String analyzeText(@RequestParam(name="text") String text){
		System.out.println("analyzed text");
		return analyzerService.toneAnalyzer(text).toString();
		
	}

}
